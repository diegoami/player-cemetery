set pagination off
set confirm off
set language c
set follow-fork-mode parent
set detach-on-fork on
break ar_frame if *(int*)&turn >= 411618 && *(char*)$rdi == 99
commands
silent
if *(int*)&turn == 411618
printf "CAPTURE TURN 411618\n"
call (int) ar_host_save("/home/diego/projects/borg-reborn-rs/vendor/player-cemetery/recordings/20261115T212321Z-PlanMage/evidence/near-death-checkpoints/t411618.save")
end
if *(int*)&turn == 411638
printf "CAPTURE TURN 411638\n"
call (int) ar_host_save("/home/diego/projects/borg-reborn-rs/vendor/player-cemetery/recordings/20261115T212321Z-PlanMage/evidence/near-death-checkpoints/t411638.save")
end
if *(int*)&turn == 411648
printf "CAPTURE TURN 411648\n"
call (int) ar_host_save("/home/diego/projects/borg-reborn-rs/vendor/player-cemetery/recordings/20261115T212321Z-PlanMage/evidence/near-death-checkpoints/t411648.save")
end
if *(int*)&turn == 411658
printf "CAPTURE TURN 411658\n"
call (int) ar_host_save("/home/diego/projects/borg-reborn-rs/vendor/player-cemetery/recordings/20261115T212321Z-PlanMage/evidence/near-death-checkpoints/t411658.save")
end
if *(int*)&turn == 411668
printf "CAPTURE TURN 411668\n"
call (int) ar_host_save("/home/diego/projects/borg-reborn-rs/vendor/player-cemetery/recordings/20261115T212321Z-PlanMage/evidence/near-death-checkpoints/t411668.save")
end
if *(int*)&turn >= 411668
disable 1
end
continue
end
run

PlanMage: recorded errand-plan and M13 shopping test

Live window: resume with Ctrl-Z then z; any key stops the Borg.
Ctrl-S saves; Ctrl-X saves and exits.

The live native save is segments/live/save/PlanMage.
An untouched resumed checkpoint is segments/live/starting.save.
The prior fresh-birth capture is segments/qualification/recording.
Current capture is segments/live/recording; diagnostics and town-plan decisions are beside it.
Frozen game and recorder binaries are in runtime/.
Session metadata and hashes are in session.json.

This is local player-cemetery storage. Remote publication is not automatic.
Native saves retain game state, not Borg process memory. Exact replay verification is tracked separately.
